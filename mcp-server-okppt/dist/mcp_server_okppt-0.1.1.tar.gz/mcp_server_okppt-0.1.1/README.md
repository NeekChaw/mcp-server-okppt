# SVG到PPTX导入工具

这是一个基于Model Context Protocol (MCP)的服务器工具，专门用于将SVG图像插入到PowerPoint演示文稿中。它能够保留SVG的矢量特性，确保在PowerPoint中显示的图像保持高品质和可缩放性。

## 主要功能

- 将SVG图像插入到PPTX文件的指定位置
- 批量处理多个SVG文件
- 创建基于SVG的全新演示文稿
- 复制包含SVG图像的幻灯片
- 替换现有幻灯片内容
- 将SVG代码直接保存为文件
- SVG转PNG转换支持

## 安装说明

### 前提条件

- Python 3.7+
- pip 包管理器

### 安装步骤

1. 克隆仓库到本地

```bash
git clone https://github.com/yourusername/svg-to-pptx.git
cd svg-to-pptx
```

2. 安装依赖

```bash
pip install -r requirements.txt
```

3. 启动MCP服务器

```bash
python main.py
```

## 工具功能详解

### 1. 插入SVG图像

```python
insert_svg(
    pptx_path="演示文稿.pptx",
    svg_path=["图表.svg"],
    slide_number=1,
    x_inches=0,
    y_inches=0,
    width_inches=16,
    height_inches=9,
    output_path="输出文件.pptx",
    create_if_not_exists=True
)
```

### 2. 列出目录文件

```python
list_files(
    directory="./images",
    file_type="svg"  # 可选参数，可以是"svg"或"pptx"
)
```

### 3. 获取文件信息

```python
get_file_info(
    file_path="图表.svg"
)
```

### 4. 转换SVG为PNG

```python
convert_svg_to_png(
    svg_path="图表.svg",
    output_path="图表.png"  # 可选，如不提供则使用相同文件名但扩展名为.png
)
```

### 5. 获取PPTX信息

```python
get_pptx_info(
    pptx_path="演示文稿.pptx"
)
```

### 6. 保存SVG代码

```python
save_svg_code(
    svg_code='<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><circle cx="50" cy="50" r="40" stroke="black" stroke-width="2" fill="red"/></svg>'
)
```

### 7. 删除幻灯片

```python
delete_slide(
    pptx_path="演示文稿.pptx",
    slide_number=2,
    output_path="修改后.pptx"  # 可选
)
```

### 8. 插入空白幻灯片

```python
insert_blank_slide(
    pptx_path="演示文稿.pptx",
    slide_number=2,
    layout_index=6,  # 默认使用空白布局
    output_path="修改后.pptx",  # 可选
    create_if_not_exists=True
)
```

### 9. 复制SVG幻灯片

```python
copy_svg_slide(
    source_pptx_path="源文件.pptx",
    target_pptx_path="目标文件.pptx",  # 如为空则创建新文件
    source_slide_number=1,
    target_slide_number=3,  # 如为None则添加到末尾
    output_path="输出文件.pptx",  # 可选
    create_if_not_exists=True
)
```

### 10. 从SVG创建PPTX

```python
create_pptx_from_svg(
    svg_paths=["第一页.svg", "第二页.svg", "第三页.svg"],
    pptx_path="",  # 可选，初始PPTX文件
    output_path="新演示文稿.pptx",  # 可选
    width_inches=16,
    height_inches=9,
    x_inches=0,
    y_inches=0
)
```

## 最佳实践

### 替换幻灯片内容的推荐方法

#### 方法一：完全替换法（最可靠）

```python
# 步骤1：删除要替换的幻灯片
delete_slide(
    pptx_path="演示文稿.pptx",
    slide_number=3,
    output_path="临时文件.pptx"
)

# 步骤2：在同一位置插入空白幻灯片
insert_blank_slide(
    pptx_path="临时文件.pptx",
    slide_number=3,
    output_path="临时文件2.pptx"
)

# 步骤3：将新SVG插入到空白幻灯片
insert_svg(
    pptx_path="临时文件2.pptx",
    svg_path=["新内容.svg"],
    slide_number=3,
    output_path="最终文件.pptx"
)
```

#### 方法二：新文件法（适合多页修改）

```python
# 一次性创建包含所有SVG的新PPTX文件
create_pptx_from_svg(
    svg_paths=["第1页.svg", "第2页.svg", "修改后的第3页.svg", "第4页.svg"],
    output_path="全新演示文稿.pptx"
)
```

## 注意事项

1. **避免内容叠加**：直接对现有幻灯片插入SVG会导致新内容叠加在原内容上，而非替换
2. **批量处理**：批量插入SVG时，`svg_path`参数必须是数组形式，即使只有一个文件
3. **SVG代码转义**：在使用`save_svg_code`时，特殊字符（如"&"）需要正确转义为"&amp;"
4. **文件路径**：尽量使用英文路径，避免路径中出现特殊字符
5. **检查结果**：每次操作后应检查输出文件以确认修改是否成功

## 常见问题解答

### Q: SVG插入后变成了位图而非矢量图？
A: 请确保使用`copy_svg_slide`或`create_pptx_from_svg`函数，这些函数专门设计用于保留SVG的矢量特性。

### Q: 如何批量处理多个SVG文件？
A: 可以使用`insert_svg`函数并将多个SVG路径作为列表传入，或者使用`create_pptx_from_svg`一次性创建包含多个SVG的演示文稿。

### Q: 文件名变得很长且复杂？
A: 这是因为每次操作都会添加时间戳。建议使用"新文件法"一次性创建最终文件，或在最后一步操作中指定简洁的输出文件名。